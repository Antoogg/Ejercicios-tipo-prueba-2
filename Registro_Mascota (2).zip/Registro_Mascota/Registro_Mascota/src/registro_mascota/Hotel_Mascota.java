/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registro_mascota;
import java.util.ArrayList;
/**
 *
 * @author Duoc
 */
public class Hotel_Mascota {
    ArrayList<Macota>mascotas=new ArrayList<>();
    
    public boolean agregarMacotas(Macota m){
        for (Macota existente: mascotas){
            if (existente.getCod().equalsIgnoreCase(m.getCod())){
                System.out.println("Ya existe una mascota con ese codigo: "+m.getCod());
                return false;
            }
        }
        mascotas.add(m);
        return true;
    }
    
    public void listarMascotas(){
        for (Macota m: mascotas){
            m.mostrarInfo();
        }
    }
    
    public int cantidadMascotas() {
        return mascotas.size();
    }

    public double totalAlojamiento() {
        double total = 0;
        for (Macota m : mascotas) {
            total += m.calcularCostoAloja(m.getDias());
        }
        return total;
    }    
}

