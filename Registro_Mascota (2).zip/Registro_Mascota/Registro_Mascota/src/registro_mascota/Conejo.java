/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registro_mascota;

/**
 *
 * @author Duoc
 */
public class Conejo extends Macota{
    protected String Dieta;

    public Conejo(String Dieta, String nom, String cod, int dias, int edad, double peso, boolean supervisionNoc) {
        super(nom, cod, dias, edad, peso, supervisionNoc);
        this.Dieta = Dieta;
    }

    public Conejo() {
    }

    public String getDieta() {
        return Dieta;
    }

    public void setDieta(String Dieta) {
        this.Dieta = Dieta;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("\nConejo - Codigo: "+getCod()+ " Nombre: "+getNom());
        System.out.println(" Peso: "+getPeso()+" Edad: "+getEdad()+" Dias de alojamiento: "+getDias());
        System.out.println(" Dieta: "+getDieta()+" Supervisión nocturna: "+isSupervisionNoc());
    }

    @Override
    public double calcularCostoAloja(int dias) {
        double valor=VALOR_DIA_ALOJAMIENTO;
        valor -= valor*0.1;
        return valor*dias;
    }
}
