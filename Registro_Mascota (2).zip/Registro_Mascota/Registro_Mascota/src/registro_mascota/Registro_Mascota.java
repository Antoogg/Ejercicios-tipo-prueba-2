/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registro_mascota;

/**
 *
 * @author Duoc
 */
public class Registro_Mascota {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Hotel_Mascota hotel = new Hotel_Mascota();

        // 3 perros
        hotel.agregarMacotas(new Perro(4, "Firulais", "M001", 5, 4, 15.2, true));
        hotel.agregarMacotas(new Perro(2, "Rex", "M002", 6, 2, 20.0, false));
        hotel.agregarMacotas(new Perro(5, "Max", "M003", 3, 5, 10.0, true));

        // 2 gatos
        hotel.agregarMacotas(new Gato("Siamés", "Michi", "G001", 2, 3, 4.5, false));
        hotel.agregarMacotas(new Gato("Persa", "Luna", "G002", 4, 2, 5.0, true));

        // 2 conejos
        hotel.agregarMacotas(new Conejo("Vegetales", "Bunny", "C001", 1, 4, 2.0, false ));
        hotel.agregarMacotas(new Conejo("Mixta", "Tambor", "C002", 2, 3, 3.0,  true ));

        // Listar todas
        System.out.println("🐾 LISTADO DE MASCOTAS ALOJADAS:");
        hotel.listarMascotas();

        // Mostrar cantidad
        System.out.println("\nTotal de mascotas alojadas: " + hotel.cantidadMascotas());

        // Calcular total general
        System.out.println("\nCosto total por todas las mascotas: $" + hotel.totalAlojamiento());
    }
}
