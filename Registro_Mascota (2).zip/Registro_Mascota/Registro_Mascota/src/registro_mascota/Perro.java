/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registro_mascota;

/**
 *
 * @author Duoc
 */
public class Perro extends Macota{
    protected int salirEjercicio;

    public Perro(int salirEjercicio, String nom, String cod, int dias, int edad, double peso, boolean supervisionNoc) {
        super(nom, cod, dias, edad, peso, supervisionNoc);
        this.salirEjercicio = salirEjercicio;
    }

    public Perro() {
    }

    public int getSalirEjercicio() {
        return salirEjercicio;
    }

    public void setSalirEjercicio(int salirEjercicio) {
        this.salirEjercicio = salirEjercicio;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("\nPerro - Codigo: "+getCod()+ " Nombre: "+getNom());
        System.out.println(" Peso: "+getPeso()+" Edad: "+getEdad()+" Dias de alojamiento: "+getDias());
        System.out.println(" Salidas diarias: "+getSalirEjercicio()+" Supervisión nocturna: "+isSupervisionNoc());
    }

    @Override
    public double calcularCostoAloja(int dias) {
        double valor=VALOR_DIA_ALOJAMIENTO;
        if (salirEjercicio>3){
            valor += valor*0.08;
        }
        return valor*dias;
    }
 
}
