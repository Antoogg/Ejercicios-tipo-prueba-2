/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registro_mascota;

/**
 *
 * @author Duoc
 */
public abstract class Macota implements Costo_Alojamiento{
    protected String nom, cod;
    protected int dias, edad;
    protected double peso;
    protected boolean supervisionNoc;

    public Macota(String nom, String cod, int dias, int edad, double peso, boolean supervisionNoc) {
        this.nom = nom;
        this.cod = cod;
        this.dias = dias;
        this.edad = edad;
        this.peso = peso;
        this.supervisionNoc = supervisionNoc;
    }

    public Macota() {
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public int getDias() {
        return dias;
    }

    public void setDias(int dias) {
        this.dias = dias;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public boolean isSupervisionNoc() {
        return supervisionNoc;
    }

    public void setSupervisionNoc(boolean supervisionNoc) {
        this.supervisionNoc = supervisionNoc;
    }
    
    //metodos abstract (debe sobreescibirse en las subclases)
    public abstract void mostrarInfo();
}
