/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package registro_mascota;

/**
 *
 * @author Duoc
 */
public class Gato extends Macota{
    protected String pedigri;

    public Gato(String pedigri, String nom, String cod, int dias, int edad, double peso, boolean supervisionNoc) {
        super(nom, cod, dias, edad, peso, supervisionNoc);
        this.pedigri = pedigri;
    }

    public Gato() {
    }

    public String getPedigri() {
        return pedigri;
    }

    public void setPedigri(String pedigri) {
        this.pedigri = pedigri;
    }
    
    @Override
    public void mostrarInfo() {
        System.out.println("\nGato - Codigo: "+getCod()+ " Nombre: "+getNom());
        System.out.println(" Peso: "+getPeso()+" Edad: "+getEdad()+" Dias de alojamiento: "+getDias());
        System.out.println(" Pedigrí: "+getPedigri()+" Supervisión nocturna: "+isSupervisionNoc());
    }

    @Override
    public double calcularCostoAloja(int dias) {
        double valor=VALOR_DIA_ALOJAMIENTO;
        valor += valor*0.01;
        return valor*dias;
    }
}
