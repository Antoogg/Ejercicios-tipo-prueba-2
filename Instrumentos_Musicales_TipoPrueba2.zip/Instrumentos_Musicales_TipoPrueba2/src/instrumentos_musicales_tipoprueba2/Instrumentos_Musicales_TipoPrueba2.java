/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package instrumentos_musicales_tipoprueba2;

/**
 *
 * @author carre
 */
public class Instrumentos_Musicales_TipoPrueba2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MejoraPro manejar = new MejoraPro(); 

        System.out.println("\n--- INGRESO DE INSTRUMENTOS (SIMULACIÓN) ---");

        // 2. Crear objetos Datos y Productos y pasarlos a la Manejadora
        // a. Guitarra Fender (Marca con DTO_NAVIDAD)
        Datos datosG1 = new Datos("G001", "Stratocaster", 450000);
        Guitarra gui1 = new Guitarra(datosG1, "Electrica", "Fender", "Player Plus Strat", 2024);
        manejar.agregarProducto(gui1); // Opción 1: Ingresar Instrumento.
        
        // b. Guitarra Ibanez (Acústica y Año 2023, cumple 2 condiciones)
        Datos datosG2 = new Datos("G002", "PF15", 300000);
        Guitarra gui2 = new Guitarra(datosG2, "acústica", "Ibanez", "PC12MH", 2023);
        manejar.agregarProducto(gui2); 
        
        // c. Piano con Incremento (Año 2023 y Teclas > 88)
        Datos datosP1 = new Datos("P001", "Gran Cola", 2500000);
        Piano piano1 = new Piano(datosP1, "de cola", "Yamaha", "C3X", 89, 2023);
        manejar.agregarProducto(piano1);
        
        // d. Intentar duplicado (No debería ingresar)
        Datos datosG3 = new Datos("G002", "Otra Guitarra", 10000.);
        Guitarra guitarra3 = new Guitarra(datosG3, "eléctrica", "ESP", "Snapper", 2024);
        manejar.agregarProducto(guitarra3); 

        // --- EJECUCIÓN DE MÉTODOS REQUERIDOS (OPCIONES DEL MENÚ) ---

        System.out.println("\n--- OP 3: APLICAR AJUSTE DE PRECIO ---");
        // Opción 3: Aplica el ajuste del 14.5% a los productos del año 2023.
        manejar.aplicarAjuste();

        System.out.println("\n--- OP 2: MOSTRAR PRECIOS FINALES ---");
        
        // G001 (Fender): DTO_NAVIDAD (6.5%) aplicado.
        manejar.mostrarPrecioFinal("G001"); // Opción 2: Mostrar Precio Final
        
        // G002 (Ibanez/2023): Ajuste de precio aplicado.
        manejar.mostrarPrecioFinal("G002");
        
        // P001 (Piano): Ajuste aplicado + Incremento de $40000.
        manejar.mostrarPrecioFinal("P001");

        System.out.println("\n--- OP 4: CONTAR GUITARRAS ---");
        // Opción 4: Contar guitarras acústicas de marca Ibanez.
        manejar.contarAcusticasIbanez();
        
        System.out.println("\n--- OP 5: SALIR ---");
    }
    
    
 
}
