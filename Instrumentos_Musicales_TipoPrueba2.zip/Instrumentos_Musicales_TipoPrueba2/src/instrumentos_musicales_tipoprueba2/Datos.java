/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instrumentos_musicales_tipoprueba2;

/**
 *
 * @author carre
 */
public class Datos {
    protected String cod, nom;
    protected double precioBase;

    public Datos(String cod, String nom, double precioBase) {
        this.cod = cod;
        this.nom = nom;
        this.precioBase = precioBase;
    }

    public Datos() {
    }

    public String getCod() {return cod;}
    public void setCod(String cod) {this.cod = cod;}
    public String getNom() {return nom;}
    public void setNom(String nom) {this.nom = nom;}
    public double getPrecioBase() {return precioBase;}
    public void setPrecioBase(double precioBase) {this.precioBase = precioBase;}
    
}
