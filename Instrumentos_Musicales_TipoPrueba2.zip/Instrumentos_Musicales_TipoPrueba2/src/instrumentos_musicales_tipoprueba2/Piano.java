/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instrumentos_musicales_tipoprueba2;

/**
 *
 * @author carre
 */
public class Piano extends Productos{
    protected int cantTeclas;
    protected String tipo_piano;

    public Piano(Datos datos, String tipo_piano, String marca, String modelo, int cantTeclas, int añoFabricado) {
        super(datos, marca, modelo, añoFabricado);
        this.cantTeclas = cantTeclas;
        this.tipo_piano = tipo_piano;
    }
    
    public Piano() {}

    public int getCantTeclas() {return cantTeclas;}
    public void setCantTeclas(int cantTeclas) {this.cantTeclas = cantTeclas;}
    
    @Override
    public double calcularIncremento() {
        if (this.cantTeclas > 88) { 
            return 40000.0; //
        }
        return 0.0;
    }
    
}
