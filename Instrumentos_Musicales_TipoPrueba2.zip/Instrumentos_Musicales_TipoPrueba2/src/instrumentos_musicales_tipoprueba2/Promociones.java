/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package instrumentos_musicales_tipoprueba2;

/**
 *
 * @author carre
 */
public interface Promociones {
    double DTO_NAVIDAD = 0.065; 
    //Calcula el descuento de Navidad.
    //Se aplica solo en el precio base solo si la marca es "Fender"
}
