/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instrumentos_musicales_tipoprueba2;

/**
 *
 * @author carre
 */
public abstract class Productos implements Promociones{
    protected Datos datos;
    protected String marca, modelo;
    protected int añoFabricado;

    public Productos(Datos datos, String marca, String modelo, int añoFabricado) {
        this.datos = datos;
        this.marca = marca;
        this.modelo = modelo;
        this.añoFabricado = añoFabricado;
    }

    public Productos() {}

    public Datos getDatos() {return datos;}
    public void setDatos(Datos datos) {this.datos = datos;}
    public String getMarca() {return marca;}
    public void setMarca(String marca) {this.marca = marca;}
    public String getModelo() {return modelo;}
    public void setModelo(String modelo) {this.modelo = modelo;}
    public int getAñoFabricado() {return añoFabricado;}
    public void setAñoFabricado(int añoFabricado) {this.añoFabricado = añoFabricado;}
    
    public abstract double calcularIncremento();
    
    public double ajustePrecio() {
        if (añoFabricado==2023) {
            return datos.getPrecioBase() * 0.145; // 14.5%
        }
        return 0.0;
    }
    
    public double precioFinal() {
        // Ya que ajustePrecio modifica el precioBase, la fórmula es:
        return datos.getPrecioBase()-ajustePrecio()+ calcularIncremento();
    }
    
    public double descuento_Navidad() {
        if (marca.equalsIgnoreCase("Fender")) {
            return precioFinal()-(datos.getPrecioBase() * DTO_NAVIDAD); // 6.5% sobre precio base
        }
        return precioFinal();
    }
    
}
