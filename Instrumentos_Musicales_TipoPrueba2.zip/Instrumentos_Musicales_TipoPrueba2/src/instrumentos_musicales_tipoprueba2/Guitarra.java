/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instrumentos_musicales_tipoprueba2;

/**
 *
 * @author carre
 */
public class Guitarra extends Productos{
    protected String tipoGui;

    public Guitarra(Datos datos, String tipoGui, String marca, String modelo, int añoFabricado) {
        super(datos, marca, modelo, añoFabricado);
        this.tipoGui = tipoGui;
    }

    public Guitarra() {}
    
    @Override
    public double calcularIncremento() {
        return 0.0; 
    }
    
    // Método de soporte para la opción "Contar Guitarras"
    public boolean esAcusticaIbanez() {
        return this.tipoGui.equalsIgnoreCase("acústica") && this.getMarca().equalsIgnoreCase("Ibanez"); 
    }
}
