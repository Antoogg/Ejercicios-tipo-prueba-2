/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package instrumentos_musicales_tipoprueba2;

/**
 *
 * @author carre
 */
import java.util.ArrayList;
import java.util.List;
public class MejoraPro {
    private ArrayList<Productos> mejorpro;

    public MejoraPro(){
        this.mejorpro=new ArrayList<>();
    }
    
    public MejoraPro(ArrayList<Productos> mejorpro) {
        this.mejorpro = mejorpro;
    }
    
    public boolean agregarProducto (Productos pro){
        for (Productos existente: this.mejorpro){
            if (existente.getDatos().getCod().equalsIgnoreCase(pro.getDatos().getCod())){
                System.out.print("Error: El producto con el código "+pro.getDatos().getCod()+" ya existe.");
                return false;
            }
        }
        mejorpro.add(pro);
        return true;
    }
    
    public double aplicarAjuste(){
        for (Productos p: this.mejorpro){
            return p.ajustePrecio();
        }
        return 0;
    }
        
    public void mostrarPrecioFinal(String codi) {
        for (Productos p : this.mejorpro) { 
            if (p.getDatos().getCod().equals(codi)) {
                System.out.println("\n--- DETALLE DEL PRODUCTO (" +codi+ ") ---");
                System.out.println("Nombre: " +p.getDatos().getNom());
                System.out.println("Precio Base Actual:\n"+ p.getDatos().getPrecioBase());
                System.out.println("Precio Final:\n"+ p.descuento_Navidad());
                return;
            }
        }
        System.out.println("Producto con código "+codi+" no encontrado.");
    }
    
    public void contarAcusticasIbanez() {
        int count = 0;
    
        for (Productos p : this.mejorpro) {
            // 1. Verificar si el objeto p es realmente una Guitarra
            if (p instanceof Guitarra) {
                // 2. Hacer el casting para acceder al método específico
                Guitarra g = (Guitarra) p; 
                // 3. Usar el método auxiliar para la condición
                if (g.esAcusticaIbanez()) {
                    count+=1;
                }
            }
        }
        System.out.println("Cantidad de guitarras acústicas de marca Ibanez: " + count);
    }
}
