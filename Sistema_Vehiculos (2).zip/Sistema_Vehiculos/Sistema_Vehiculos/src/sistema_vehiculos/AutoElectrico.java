/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_vehiculos;

/**
 *
 * @author Duoc
 */
public class AutoElectrico extends Auto implements Electrico{
    protected int bateria;

    public AutoElectrico(int bateria, boolean pilotoAutomatico, String marca, String modelo, int velocidadActual) {
        super(pilotoAutomatico, marca, modelo, velocidadActual);
        this.bateria = bateria;
    }

    public AutoElectrico(int bateria, boolean pilotoAutomatico) {
        super(pilotoAutomatico);
        this.bateria = bateria;
    }
    
    public void acelerar() {
        System.out.println("Acelerando en modo ecológico.");
    }
    
    @Override
    public int nivelBateria(){
        return bateria;
    }
    
    @Override
    public void cargarBateria(){
        System.out.println("Cargando bateria.");
    }
    
    public final void mostrarEstado(){
        System.out.println("Marca: "+marca+", Modelo: "+modelo+"Piloto automatico: "+pilotoAutomatico);
        System.out.println("Nivel de bateria: "+nivelBateria());
        if (nivelBateria()<50){
            cargarBateria();
        }
    }
}
