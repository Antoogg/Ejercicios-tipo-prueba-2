/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_vehiculos;

/**
 *
 * @author Duoc
 */
public class Moto extends Vehiculo{

    public Moto(String marca, String modelo, int velocidadActual) {
        super(marca, modelo, velocidadActual);
    }

    public Moto() {
    }
    
    @Override
    public final void acelerar(int incremento){
        velocidadActual+=incremento;
        System.out.println("Moto: Su velocidad tuvo un incremento de "+incremento+" y su velocidad actual es: "+velocidadActual);
    }
}
