/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_vehiculos;

/**
 *
 * @author Duoc
 */
public abstract class Vehiculo {
    protected String marca, modelo;
    protected int velocidadActual;

    public Vehiculo(String marca, String modelo, int velocidadActual) {
        this.marca = marca;
        this.modelo = modelo;
        this.velocidadActual = velocidadActual;
    }

    public Vehiculo() {
    }
    
    public abstract void acelerar(int incremento);
    
    public void frenar(int decremento){
        velocidadActual=velocidadActual-decremento;
        if (velocidadActual<0 | velocidadActual==0){
            System.out.println("No puede ser menor que 0km/h. ");
        }else{
            System.out.println("Has bajado "+decremento+" km/h, tu velocidad ahora es de "+velocidadActual);
        }
    }
}
