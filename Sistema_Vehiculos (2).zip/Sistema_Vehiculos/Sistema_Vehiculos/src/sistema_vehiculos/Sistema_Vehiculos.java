/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistema_vehiculos;

/**
 *
 * @author Duoc
 */
import java.util.ArrayList;
public class Sistema_Vehiculos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic 
        ArrayList<Vehiculo> ListVehiculos=new ArrayList<>();
        
        ListVehiculos.add(new Auto(false, "Subarú", "Impresa", 50));
        ListVehiculos.add(new Moto("Yamaha", "R6", 120));
        ListVehiculos.add(new AutoElectrico(40, true, "Tesla", "Model 3", 80));
        
        for (Vehiculo v: ListVehiculos){
            v.acelerar(20);
            v.frenar(10);
        }
    }
}
