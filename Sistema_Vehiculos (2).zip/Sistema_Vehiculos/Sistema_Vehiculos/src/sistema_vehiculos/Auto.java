/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistema_vehiculos;

/**
 *
 * @author Duoc
 */
public class Auto extends Vehiculo{
    protected boolean pilotoAutomatico;

    public Auto(boolean pilotoAutomatico, String marca, String modelo, int velocidadActual) {
        super(marca, modelo, velocidadActual);
        this.pilotoAutomatico = pilotoAutomatico;
    }

    public Auto(boolean pilotoAutomatico) {
        this.pilotoAutomatico = pilotoAutomatico;
    }
    
    @Override
    public void acelerar(int incremento){
        velocidadActual+=incremento;
        System.out.println("Auto: Su velocidad tuvo un incremento de "+incremento+" y su velocidad actual es: "+velocidadActual);
    }
    
    @Override
    public void frenar(int decremento){
        super.frenar(decremento);
        if (velocidadActual<50){
            System.out.println("Piloto automatico activado. Has bajado de los 50km/h.");
        }
    }
}
