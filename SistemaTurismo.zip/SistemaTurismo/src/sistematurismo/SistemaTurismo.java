/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package sistematurismo;
import java.util.Scanner;

/**
 *
 * @author ddiaz
 */
public class SistemaTurismo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        Catalogo catalogo = new Catalogo();
        boolean salir = false;
        
        do{
            System.out.println("\n--- Bucolico S.A. ---");
            System.out.println("1. Ingresar Excursion"); 
            System.out.println("2. Mostrar Información de Excursion");
            System.out.println("3. Aplicar Ajuste de Precio (a todas)");
            System.out.println("4. Eliminar Excursion");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opcion: ");
            
            int opcion = sc.nextInt();
            sc.nextLine(); // Limpiar buffer
            
            switch (opcion){
                case 1:
                    ingresarExcursion(sc, catalogo);
                case 2:
                    mostrarInformacion(sc, catalogo);
                    break;
                case 3:
                    aplicarAjuste(catalogo);
                    break;
                case 4:
                    eliminarExcursion(sc, catalogo);
                    break;
                case 5:
                    salir = true;
                    System.out.println("Saliendo del sistema...");
                    break;
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
            
        } while (!salir);
        
    }
    
    //Metodos para el menu
        private static void ingresarExcursion(Scanner sc, Catalogo catalogo){
            System.out.println("--- INGRESAR EXCURSION ---");
            System.out.println("-> TIPO");
            System.out.println("1) Aventura");
            System.out.println("2) Cultural");
            
            int tipo = sc.nextInt();
            sc.nextLine(); // Limpiar buffer
            
            if (tipo != 1 && tipo != 2){
                System.out.println("ERROR: TIPO NO VALIDO.");
                
            }else{
                System.out.print("Codigo: ");
                String codigo = sc.nextLine();
                System.out.print("Nombre: ");
                String nombre = sc.nextLine();
                System.out.print("Duracion (horas): ");
                int duracion = Integer.parseInt(sc.nextLine());
                System.out.print("Precio Base: ");
                double precioBase = Double.parseDouble(sc.nextLine());
                System.out.print("Dificultad (Baja/Media/Alta): ");
                String dificultad = sc.nextLine();
                
                if (tipo == 1){
                    System.out.print("Deporte (Rafting/Escalada/Trekking): ");
                    String deporte = sc.nextLine();
                    System.out.print("Equipamiento (Sí/No): ");
                    String equipamiento = sc.nextLine();
                    
                    Aventura aventura1 = new Aventura(codigo, nombre, duracion, precioBase, dificultad, deporte, equipamiento);
                    
                    if (catalogo.agregarExcursion(aventura1)){
                        System.out.println("Excursion agregada con exito!");
                    } else {
                        System.out.println("Error: El codigo " + codigo + " ya existe!." );
                    }
                
                }else if (tipo == 2){
                    System.out.print("Destino Histórico: ");
                    String destino = sc.nextLine();
                    System.out.print("Idioma Guía (Inglés/Español/etc.): ");
                    String idioma = sc.nextLine();
                    
                    Cultural cultural1 = new Cultural(codigo, nombre, duracion, precioBase, dificultad, destino, idioma);
                    if (catalogo.agregarExcursion(cultural1)){
                        System.out.println("Excursion agregada con exito!");
                    } else {
                        System.out.println("Error: El codigo " + codigo + " ya existe!." );
                    }
                }
            }
        }
        
        private static void mostrarInformacion(Scanner sc, Catalogo catalogo){
            System.out.println("--- Mostrar Informacion ---");
            System.out.print("Ingrese el codigo de la excursion: ");
            String codigo = sc.nextLine();

            Excursion exc = catalogo.buscarExcursion(codigo);

            if (exc != null) {
                // Usamos el método toString() que sobrescribimos
                System.out.println(exc.toString());
            } else {
                System.out.println("Error: No se encontró la excursión con código '" + codigo + "'.");
            }
        }
        
        private static void aplicarAjuste(Catalogo catalogo) {
        System.out.println("--- Aplicando Ajuste de Precio ---");
        catalogo.aplicarAjusteATodas();
        System.out.println("Se ha aplicado el ajuste (15% dcto. si es dificultad 'baja') a todas las excursiones.");
        }
        
        private static void eliminarExcursion(Scanner sc, Catalogo catalogo) {
        System.out.println("--- Eliminar Excursión ---");
        System.out.print("Ingrese el codigo de la excursion a eliminar: ");
        String codigo = sc.nextLine();
        
        if (catalogo.eliminarExcursion(codigo)) {
            System.out.println("Excursion eliminada con exito.");
        } else {
            System.out.println("Error: No se encontro la excursion con codigo '" + codigo + "'.");
        }
        
        }
    
}
