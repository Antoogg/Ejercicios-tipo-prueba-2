/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistematurismo;
import java.util.ArrayList;

/**
 *
 * @author ddiaz
 */
public class Catalogo {
    //Atributos
    private ArrayList<Excursion> listaExcursiones;
    
    //Iniciar la lista
    public Catalogo(){
        this.listaExcursiones = new ArrayList<>();
    }
    //Constructores
    public Catalogo(ArrayList<Excursion> listaExcursiones) {
        this.listaExcursiones = listaExcursiones;
    }
    
    //Metodos
    
    public boolean agregarExcursion (Excursion e){
        for (Excursion existente: listaExcursiones){
            if (existente.getCodigo().equalsIgnoreCase(e.getCodigo())){
                System.out.print("Ya existe una mascota con ese codigo: "+ e.getCodigo());
                return false;
            }
        }
        listaExcursiones.add(e);
        return true;
    }
    
    public Excursion buscarExcursion(String codigo){
        for (Excursion exc : this.listaExcursiones){
            if (exc.getCodigo().equalsIgnoreCase(codigo)){
                return exc;
            }
        }
        return null;
    }
    
    public void aplicarAjusteATodas() {
        for (Excursion exc : this.listaExcursiones) {
            exc.disminuirBase();
        }
    }
    
    public double calcularDescuentoTotal() {
        double totalAhorrado = 0;
        for (Excursion exc : this.listaExcursiones) {
            // Acumula el descuento de cada excursión
            totalAhorrado += exc.aplicarDescuento();
        }
        return totalAhorrado;
    }
    
    public boolean eliminarExcursion(String codigo){
        Excursion excursionEliminar = buscarExcursion(codigo);
        if (excursionEliminar != null){
            this.listaExcursiones.remove(excursionEliminar);
            return true;
        }
        return false;
    }
}
