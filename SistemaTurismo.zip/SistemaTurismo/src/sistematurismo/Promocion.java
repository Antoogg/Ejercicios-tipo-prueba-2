/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package sistematurismo;

/**
 *
 * @author ddiaz
 */
public interface Promocion {
    double DTO_TEM = 0.20;
    
    //Metodo abstracto
    double aplicarDescuento ();
}
