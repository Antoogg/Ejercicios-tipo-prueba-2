/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistematurismo;

/**
 *
 * @author ddiaz
 */
public abstract class Excursion implements Promocion {
    //Atributos
    protected String codigo;
    protected String nombre;
    protected int duracion;
    protected double precioBase;
    protected String dificultad;
    
    //Constructores
    public Excursion(String codigo, String nombre, int duracion, double precioBase, String dificultad) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.duracion = duracion;
        this.precioBase = precioBase;
        this.dificultad = dificultad;
    }

    public Excursion() {
    }
    
    //Gett y sett
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public double getPrecioBase() {
        return precioBase;
    }

    public void setPrecioBase(double precioBase) {
        this.precioBase = precioBase;
    }

    public String getDificultad() {
        return dificultad;
    }

    public void setDificultad(String dificultad) {
        this.dificultad = dificultad;
    }
    
    //Metodos
    public void disminuirBase(){
        if (this.dificultad.equalsIgnoreCase("Baja")){
            this.precioBase = this.precioBase * 0.85;
        }
    }
    
    @Override
    public double aplicarDescuento(){
        if (this.duracion > 5){
            if (this.dificultad.equalsIgnoreCase("Alta")){
                return this.precioBase = this.precioBase - (this.precioBase * DTO_TEM);
            }
        }
        return 0;
    }
    
    public abstract double calcularCostoAdicional();
    
    @Override
    public String toString() {
        return "Excursion{" +
                "codigo='" + codigo + '\'' +
                ", nombre='" + nombre + '\'' +
                ", duracion=" + duracion + " horas" +
                ", preciobase=" + precioBase +
                ", dificultad='" + dificultad + '\'' +
                '}';
    }
}
