/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistematurismo;

/**
 *
 * @author ddiaz
 */
public class Cultural extends Excursion{
    //Atributos
    private String destinoHistorico;
    private String idiomaDelGuia;
    
    //Constructores
    public Cultural(String destinoHistorico, String idiomaDelGuia, int duracion, double precioBase, String codigo, String nombre, String dificultad) {
        super(codigo, nombre, duracion, precioBase, dificultad);
        this.destinoHistorico = destinoHistorico;
        this.idiomaDelGuia = idiomaDelGuia;
    }

    public Cultural(String destinoHistorico, String idiomaDelGuia) {
        this.destinoHistorico = destinoHistorico;
        this.idiomaDelGuia = idiomaDelGuia;
    }
    
    //Gett y sett
    public String getDestinoHistorico() {
        return destinoHistorico;
    }

    public void setDestinoHistorico(String destinoHistorico) {
        this.destinoHistorico = destinoHistorico;
    }

    public String getIdiomaDelGuia() {
        return idiomaDelGuia;
    }

    public void setIdiomaDelGuia(String idiomaDelGuia) {
        this.idiomaDelGuia = idiomaDelGuia;
    }
    
    //Metodos
    @Override
    public double calcularCostoAdicional() {
        if (this.idiomaDelGuia.equalsIgnoreCase("Ingles")){
        double aumento = (precioBase * 0.05);
            this.precioBase = this.precioBase + aumento;
            return aumento;
        }
        return 0;
    }
    
    @Override
    public String toString() {
        // Llama al toString() de la clase padre (Excursion) y añade lo nuevo
        return super.toString().replace("}", "") + // Truco para quitar el '}' del padre
                ", tipo=Cultural" +
                ", destinoHistorico='" + destinoHistorico + '\'' +
                ", idiomaGuia='" + idiomaDelGuia + '\'' +
                '}';
    }
}
