/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistematurismo;

/**
 *
 * @author ddiaz
 */
public class Aventura extends Excursion{
    //Atributos
    public String deporte;
    public String equipamiento;
    
    //Constructores

    public Aventura(String deporte, String equipamiento, int duracion, double precioBase, String codigo, String nombre, String dificultad) {
        super(codigo, nombre, duracion, precioBase, dificultad);
        this.deporte = deporte;
        this.equipamiento = equipamiento;
    }

    public Aventura(String deporte, String equipamiento) {
        this.deporte = deporte;
        this.equipamiento = equipamiento;
    }
    
    //Gett y sett

    public String getDeporte() {
        return deporte;
    }

    public void setDeporte(String deporte) {
        this.deporte = deporte;
    }

    public String getEquipamiento() {
        return equipamiento;
    }

    public void setEquipamiento(String equipamiento) {
        this.equipamiento = equipamiento;
    }
    
    //Metodos

    @Override
    public double calcularCostoAdicional() {
        if (this.deporte.equalsIgnoreCase("Rafting")){
            double aumento = (precioBase * 0.05);
            this.precioBase = this.precioBase + aumento;
            return aumento;
        }
        return 0;
    }
    
    // Sobrescribimos toString() para añadir la info específica de Aventuras
    @Override
    public String toString() {
        // Llama al toString() de la clase padre (Excursion) y añade lo nuevo
        return super.toString().replace("}", "") + // Truco para quitar el '}' del padre
                ", tipo=Aventura" +
                ", deporte='" + deporte + '\'' +
                ", equipamiento='" + equipamiento + '\'' +
                '}';
    }
    
}
